/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author LENOVO
 */
public class modeltabelriwayat extends AbstractTableModel{
    
    List<datariwayat> dr;
    public modeltabelriwayat(List<datariwayat>dr){
        this.dr = dr;
    }
    @Override
    public int getRowCount() {
        return dr.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "NIK";
            case 1:
                return "NAMA";
            case 2:
                return "ID_BUKU";
            case 3:
                return "JUDUL_BUKU";
            case 4:
                return "TANGGAL_PINJAM";
            default:
                return null;
        }
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dr.get(row).getNik();
            case 1:
                return dr.get(row).getNama();
            case 2:
                return dr.get(row).getId_buku();
            case 3:
                return dr.get(row).getJudul_buku();
            case 4:
                return dr.get(row).getTanggal_pinjam();
            default:
                return null;
    }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOPerpustakaan;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import DAOImplement.datariwayatimplement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author LENOVO
 */
public class datariwayatDAO implements datariwayatimplement{
    Connection connection;
    final String select = "SELECT nik, nama, id_buku, judul_buku, tanggal_pinjam FROM riwayat";
    final String insert = "INSERT INTO riwayat (nik, nama, id_buku, judul_buku, tanggal_pinjam, tanggal_kembali) VALUES (?, ?, ?, ?, ?, ?)";
    final String update = "update riwayat set nik=?, nama=?, id_buku=?, judul_buku=?, tanggal_pinjam=? where nik=?";
    final String delete = "delete from riwayat where nik=?";
    public datariwayatDAO(){
        connection = connector.connection();
    }
    
    @Override
    public void insert(datariwayat r) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, r.getNik());
            statement.setString(2, r.getNama());
            statement.setString(3, r.getId_buku());
            statement.setString(4, r.getJudul_buku());
            statement.setString(5, r.getTanggal_pinjam());
            if (r.getTanggal_kembali() == null) {
            statement.setNull(6, Types.DATE);
            } else {
                statement.setString(6, r.getTanggal_kembali());
            }
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(datariwayat r) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(update);
            statement.setString(1, r.getNik());
            statement.setString(2, r.getNama());
            statement.setString(3, r.getId_buku());
            statement.setString(4, r.getJudul_buku());
            statement.setString(5, r.getTanggal_pinjam());
            statement.setString(6, r.getNik());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void delete(String nik) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(delete);
            statement.setString(1, nik);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<datariwayat> getAll() {
        List<datariwayat> dr = null;
        try{
            dr = new ArrayList<datariwayat>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                datariwayat riwayat = new datariwayat();
                riwayat.setNik(rs.getString("nik"));
                riwayat.setNama(rs.getString("nama"));
                riwayat.setId_buku(rs.getString("id_buku"));
                riwayat.setJudul_buku(rs.getString("judul_buku"));
                riwayat.setTanggal_pinjam(rs.getString("tanggal_pinjam"));
                dr.add(riwayat);
            }
        }catch(SQLException ex){
            Logger.getLogger(datariwayatDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dr;
    }
    
}

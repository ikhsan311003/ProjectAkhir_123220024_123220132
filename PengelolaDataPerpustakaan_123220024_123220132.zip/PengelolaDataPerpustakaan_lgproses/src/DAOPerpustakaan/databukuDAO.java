/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOPerpustakaan;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import DAOImplement.databukuimplement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author LENOVO
 */
public class databukuDAO implements databukuimplement{
    Connection connection;
    final String select = "SELECT * FROM buku";
    final String insert = "INSERT INTO buku (id_buku, judul_buku, penerbit, tahun_terbit, penulis, stock) VALUES (?, ?, ?, ?, ?, ?)";
    final String update = "update buku set id_buku=?, judul_buku=?, penerbit=?, tahun_terbit=?, penulis=? where id_buku=?";
    final String delete = "delete from buku where id_buku=?";
    final String search = "SELECT * FROM `buku` WHERE judul_buku LIKE ?";
    
    public databukuDAO(){
        connection = connector.connection();
    }

    @Override
    public void insert(databuku b) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, b.getId_buku());
            statement.setString(2, b.getJudul_buku());
            statement.setString(3, b.getPenerbit());
            statement.setInt(4, b.getTahun_terbit());
            statement.setString(5, b.getPenulis());
            if (b.getStock() == null) {
            statement.setNull(6, Types.INTEGER);
            } else {
                statement.setInt(6, b.getStock());
            }
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(databuku b) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(update);
            statement.setString(1, b.getId_buku());
            statement.setString(2, b.getJudul_buku());
            statement.setString(3, b.getPenerbit());
            statement.setInt(4, b.getTahun_terbit());
            statement.setString(5, b.getPenulis());
            statement.setString(6, b.getId_buku());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void delete(String id_buku) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(delete);
            statement.setString(1, id_buku);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<databuku> getAll() {
        List<databuku> db = null;
        try{
            db = new ArrayList<databuku>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                databuku buku = new databuku();
                buku.setId_buku(rs.getString("id_buku"));
                buku.setJudul_buku(rs.getString("judul_buku"));
                buku.setPenerbit(rs.getString("penerbit"));
                buku.setTahun_terbit(rs.getInt("tahun_terbit"));
                buku.setPenulis(rs.getString("penulis"));
                db.add(buku);
            }
        }catch(SQLException ex){
            Logger.getLogger(databukuDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return db;
    }
    
        public List<databuku> search(String judul_buku) {
        List<databuku> db = new ArrayList<>();
        PreparedStatement statement = null;
        try {
        statement = connection.prepareStatement(search);
        statement.setString(1, "%" + judul_buku + "%");
        ResultSet rs = statement.executeQuery();
        while (rs.next()) {
            databuku buku = new databuku();
                buku.setId_buku(rs.getString("id_buku"));
                buku.setJudul_buku(rs.getString("judul_buku"));
                buku.setPenerbit(rs.getString("penerbit"));
                buku.setTahun_terbit(rs.getInt("tahun_terbit"));
                buku.setPenulis(rs.getString("penulis"));
                db.add(buku); 
            }
         } catch (SQLException ex) {
            ex.printStackTrace();
           } finally {
                try {
                    if (statement != null) statement.close();
                } catch (SQLException ex) {
            ex.printStackTrace(); } }
            return db;
    }

 

}


    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImplement;
import java.util.List;
import model.*;
/**
 *
 * @author LENOVO
 */
public interface datariwayatimplement {
    public void insert(datariwayat r);
    public void update(datariwayat r);
    public void delete(String nik);
    public List<datariwayat> getAll();
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOPerpustakaan.datariwayatDAO;
import DAOImplement.datariwayatimplement;
import model.*;
import view.MainViewPeminjaman;
import javax.swing.JOptionPane;
/**
 *
 * @author LENOVO
 */
public class datariwayatcontroller {
    MainViewPeminjaman frame;
    datariwayatimplement impldatariwayat;
    List<datariwayat> dr;
    
    public datariwayatcontroller(MainViewPeminjaman frame){
        this.frame = frame;
        impldatariwayat = new datariwayatDAO();
        dr= impldatariwayat.getAll();
    }
    public void isitabbel(){
        dr =impldatariwayat.getAll();
        modeltabelriwayat mr = new modeltabelriwayat(dr);
        frame.getTabeldatariwayat().setModel(mr);
    }
    public void insert(){
        String nik = frame.getjTextnik().getText();
        
        if (isNIKExists(nik)) {
        JOptionPane.showMessageDialog(null, "NIK sudah digunakan", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            datariwayat dr = new datariwayat();
            dr.setNik(frame.getjTextnik().getText());
            dr.setNama(frame.getjTextnama().getText());
            dr.setId_buku(frame.getjTextid().getText());
            dr.setJudul_buku(frame.getjTextjudul().getText());
            dr.setTanggal_pinjam(frame.getjTexttanggalpinjam().getText());
            String kembali = null;
            dr.setTanggal_kembali(kembali);
            impldatariwayat.insert(dr);

            frame.getjTextnik().setText("");
            frame.getjTextnama().setText("");
            frame.getjTextid().setText("");
            frame.getjTextjudul().setText("");
            frame.getjTexttanggalpinjam().setText("");
        
            String ObjButtons[]={"OK"};
            int PromptResult = JOptionPane.showOptionDialog(null, "Data berhasil disimpan", "Edit Data", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, ObjButtons, ObjButtons[0]);

            if (PromptResult == JOptionPane.OK_OPTION) {
                
            } 
            
        }
        
    }
        
    public void update(){
        datariwayat dr = new datariwayat();
        dr.setNik(frame.getjTextnik().getText());
        dr.setNama(frame.getjTextnama().getText());
        dr.setId_buku(frame.getjTextid().getText());
        dr.setJudul_buku(frame.getjTextjudul().getText());
        dr.setTanggal_pinjam(frame.getjTexttanggalpinjam().getText());
        impldatariwayat.update(dr);
        
        frame.getjTextnik().setText("");
        frame.getjTextnama().setText("");
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTexttanggalpinjam().setText("");
    }
     public void delete(String nik) {
        impldatariwayat.delete(nik);
    
        frame.getjTextnik().setText("");
        frame.getjTextnama().setText("");
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTexttanggalpinjam().setText("");
    }
    private boolean isNIKExists(String nik) {
        boolean exists = false;
        List<datariwayat> list = impldatariwayat.getAll();
        for (datariwayat r : list) {
            if (r.getNik().equals(nik)) {
                exists = true;
                break;
            }
        }
        return exists;
    }
}

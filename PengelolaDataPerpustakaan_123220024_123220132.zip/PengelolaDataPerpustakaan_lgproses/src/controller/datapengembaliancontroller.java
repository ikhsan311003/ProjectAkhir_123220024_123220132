/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOPerpustakaan.datapengembalianDAO;
import DAOImplement.datariwayatimplement;
import model.*;
import view.MainViewPengembalian;
import javax.swing.JOptionPane;
/**
 *
 * @author LENOVO
 */
public class datapengembaliancontroller {
    MainViewPengembalian frame;
    datariwayatimplement impldatariwayat;
    List<datariwayat> dr;
    
    public datapengembaliancontroller(MainViewPengembalian frame){
        this.frame = frame;
        impldatariwayat = new datapengembalianDAO();
        dr= impldatariwayat.getAll();
    }
    public void isitabbel(){
        dr =impldatariwayat.getAll();
        modeltabeldatapengembalian mp = new modeltabeldatapengembalian(dr);
        frame.getTabeldatapengembalian().setModel(mp);
    }
    public void insert(){
            datariwayat dr = new datariwayat();
            dr.setNik(frame.getjTextnik().getText());
            dr.setNama(frame.getjTextpeminjam().getText());
            dr.setId_buku(frame.getjTextid().getText());
            dr.setJudul_buku(frame.getjTextjudul().getText());
            dr.setTanggal_pinjam(frame.getjTexttanggalpinjam().getText());
            dr.setTanggal_kembali(frame.getjTexttanggalkembali().getText());
            impldatariwayat.insert(dr);

            frame.getjTextnik().setText("");
            frame.getjTextpeminjam().setText("");
            frame.getjTextid().setText("");
            frame.getjTextjudul().setText("");
            frame.getjTexttanggalpinjam().setText("");
            frame.getjTexttanggalkembali().setText("");
        
    }
        
    public void update(){
        datariwayat dr = new datariwayat();
        dr.setNik(frame.getjTextnik().getText());
        dr.setNama(frame.getjTextpeminjam().getText());
        dr.setId_buku(frame.getjTextid().getText());
        dr.setJudul_buku(frame.getjTextjudul().getText());
        dr.setTanggal_pinjam(frame.getjTexttanggalpinjam().getText());
        dr.setTanggal_kembali(frame.getjTexttanggalkembali().getText());
        impldatariwayat.update(dr);
        
        frame.getjTextnik().setText("");
        frame.getjTextpeminjam().setText("");
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTexttanggalpinjam().setText("");
        frame.getjTexttanggalkembali().setText("");
    }
}
